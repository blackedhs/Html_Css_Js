var arr = [1,2,3,4,5,6];
var cuadrado = arr.map(function(elemento){
    return elemento * elemento;
});

console.log(cuadrado);